function confirmDelete() {
    return confirm("Are you sure you want to delete this recipe?");
}
