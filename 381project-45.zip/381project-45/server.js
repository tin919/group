const express = require('express');
const mongoose = require('mongoose');
const session = require('express-session');
const MongoStore = require('connect-mongo');
const bcrypt = require('bcryptjs');
const bodyParser = require('body-parser');
const User = require('./models/userModel');
const Recipe = require('./models/recipeModel');

const app = express();

// MongoDB connection
const uri = 'mongodb+srv://dbUser:db_password@cluster0.tllmk.mongodb.net/recipe-book?retryWrites=true&w=majority&appName=Cluster0';

mongoose.connect(uri, {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
.then(() => console.log("MongoDB connected"))
.catch(err => console.error("MongoDB connection error:", err));

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({
    secret: 'secretKey',
    resave: false,
    saveUninitialized: false,
    store: MongoStore.create({ mongoUrl: uri })
}));

app.set('view engine', 'ejs');
app.use(express.static('public'));

// Middleware for authentication
function isAuthenticated(req, res, next) {
    if (req.session.user) return next();
    res.redirect('/login');
}

// Routes
app.get('/', (req, res) => {
    res.redirect('/login');
});

app.get('/login', (req, res) => res.render('login', { error: null }));

app.post('/login', async (req, res) => {
    const { username, password } = req.body;
    const user = await User.findOne({ username });

    // Check if user exists and compare passwords
    if (user && await bcrypt.compare(password, user.password)) {
        req.session.user = user;
        res.redirect('/dashboard');
    } else {
        // If credentials are invalid, pass an error message to the login page
        res.render('login', { error: 'Invalid username or password.' });
    }
});

// Register route
app.get('/register', (req, res) => res.render('register'));
app.post('/register', async (req, res) => {
    const { username, password, confirmPassword } = req.body;

    if (password !== confirmPassword) {
        return res.render('error', { message: 'Passwords do not match' });
    }

    const existingUser = await User.findOne({ username });
    if (existingUser) {
        return res.render('error', { message: 'Username already exists' });
    }

    const hashedPassword = await bcrypt.hash(password, 10); // Hash password
    const user = new User({ username, password: hashedPassword });
    await user.save();

    console.log('New user created:', user);  // Debugging log

    res.redirect('/login');
});

app.get('/logout', (req, res) => {
    req.session.destroy(() => res.redirect('/login'));
});

app.get('/dashboard', isAuthenticated, async (req, res) => {
    const recipes = await Recipe.find({});
    res.render('dashboard', { recipes });
});

// CRUD for recipes
app.post('/recipes', isAuthenticated, async (req, res) => {
    const { title, ingredients, instructions } = req.body;
    const recipe = new Recipe({ title, ingredients, instructions });
    await recipe.save();
    res.redirect('/dashboard');
});

app.post('/recipes/update/:id', isAuthenticated, async (req, res) => {
    const { id } = req.params;
    const { title, ingredients, instructions } = req.body;
    await Recipe.findByIdAndUpdate(id, { title, ingredients, instructions });
    res.redirect('/dashboard');
});

app.get('/recipes/delete/:id', isAuthenticated, async (req, res) => {
    const { id } = req.params;
    await Recipe.findByIdAndDelete(id);
    res.redirect('/dashboard');
});

app.listen(8099, () => console.log('Server running on http://localhost:8099'));
